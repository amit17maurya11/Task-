var splide = new Splide( '.splide', {
    type   : 'loop',
    padding: '5rem',
  } );
  
  splide.mount();